'''
enumerate(<参数>) 是python的内置函数、在是枚举的意思。enumerate(<参数>)
参数为可遍历的对象(如列表、字符串)用 for循环计数，
可以同时获得索引index和值value。enumerate (<参数>)返回一个enumerate对象，该对象通过list()
转换为列表。
Python list内置sort()方法用来排序，也可以用python内置的全局sorted()方法来对可迭代的序列排序生成新的序列
使用sort()方法对list排序会修改list本身,不会返回新list，通常此方法不如sorted()方便，但是如果你不需要保留原来的list，此方法将更有效sort()。
sort()不能对dict字典进行排序
list.sort()和sorted()函数增加了key参数来指定一个函数，此函数将在每个元素比较前被调用
 
key参数的值为一个函数，此函数只有一个参数且返回一个值用来进行比较。
这个技术是快速的因为key指定的函数将准确地对每个元素调用。
sorted()的reverse参数接受False 或者True 表示是否逆序


'''

#统计字符串中每个字符、单词、中大写小写字母出现的次数和单词总量
st="Python is an easy to learn, powerful programming language.\
     It has efficient high-level data structures and \
     a simple but effective approach to object-oriented programming. \
     Python’s elegant syntax and dynamic typing, together with its \
     interpreted nature, make it an ideal language for scripting and\
     rapid application development in many areas on most platforms."
#print( '------统计字符串中每个字符出现的次数------')
#print('------简单直接输出----------')
#print([(x,st.count(x)) for x in set(st)])



'''
print('------------格式化直接输出--------------------')
for  index,value in enumerate([x for x in set(st)],1):
     print(index,value,'出现',st.count(value),'次')

'''
#print('------统计字符串中每个单词出现的次数----------')
#print('------简单直接输出----------')
print(set(st))
print('--------------------------------')
print([(x,st.count(x)) for x in set(st)])
print('--------------------------------')
result=[(x,st.count(x)) for x in set(st)]
res=sorted(result, key=lambda result:result[1],reverse=True)
print(res)
print('--------------------------------')      
print(st.split())
print('--------------------------------')
print([(x,st.count(x)) for x in st.split()])  #st.split()分割单词
print('--------------------------------')
result=[(x,st.count(x)) for x in st.split()]
res=sorted(result, key=lambda result:result[1],reverse=True)
print(res)
'''
print('------------格式化直接输出--------------------')
for  index,value in enumerate([i for i in st.split()],1):
     print(index,value,'出现',st.count(value),'次')
for  index,value in enumerate(['Python','programming']):
     print(index,value,'出现',st.count(value),'次')

print('\n-------统计字符串中单词总量----------')
print('字符串中单词总量=',len([i for i in st.split()]),'个')

print( '------统计字符串中每个字符出现的次数排序------')
result=[(x,st.count(x)) for x in set(st)]
res=sorted(result, key=lambda result:result[1],reverse=True)
for i in range(len(res)):
    print(i+1,res[i])
print( '------统计字符串中每个单词出现的次数排序------')
result=[(x,st.count(x)) for x in st.split()]
res=sorted(result, key=lambda result:result[1],reverse=True)
for i in range(len(res)):
    print(i+1,res[i])
'''
