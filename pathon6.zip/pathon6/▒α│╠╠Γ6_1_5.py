'''
enumerate(<参数>) 是python的内置函数、在是枚举的意思。enumerate(<参数>)
参数为可遍历的对象(如列表、字符串)用 for循环计数，
可以同时获得索引index和值value。enumerate (<参数>)返回一个enumerate对象，该对象通过list()
转换为列表。
'''

''''
在Python中，lambda的语法是唯一的。其形式如下：

     lambda argument_list: expression

其中，lambda是Python预留的关键字，argument_list和expression由用户自定义。

函数 lambda student:student[2]返回的值分别是10， 12， 15。
 
所以就用函数返回的值进行比较；key=15 ，key=12，key=10根据这些返回值进行比较；
 
lambda student:student[2] 等价于
 
def f(student):
 
    return student[2]
student = [
        ('john', 'A', 15),
        ('jane', 'B', 12),
        ('dave', 'B', 10),
]

result = sorted(student, key=lambda student:student[2],reverse=True)
print(result)
'''
#!/usr/bin/envpython
li=[{"name":"mary","age":20},{"name":"john","age":25},{"name":"alice","age":10}]
li=sorted(li, key=lambda x:x["age"],reverse=True)
#for index,value in enumerate(lst):
print(li)
for i in range(len(li)):
    print(li[i])
#编程题1
print('\n------------编程题1--------------')
lst = [chr(i) for i in range(97,123)]
s='aaabbcdefgadbbfbfbfbfbGGGGGGGGGGGGGGGGGGG'
s=s.lower()
result=[]
for index,value in enumerate(lst):
    print(index,value,s.count(value))
    result.append((index,value,s.count(value)))
res=sorted(result, key=lambda result:result[2],reverse=True)
for i in range(len(res)):
    print(res[i])
#编程题2    
print('\n------------编程题2--------------')
s='aaabbc统计文件中某字符或每个字符出现的次数GGGGGGGGGGG'
result=[(x,s.count(x)) for x in set(s)]
res=sorted(result, key=lambda result:result[1],reverse=True)
for i in range(len(res)):
    print(res[i])

#编程题3
import random,string
src = string.ascii_letters + string.digits
passwds = []  #保存符合要求的密码
count = input('请输入密码个数(必须大于0)： ')
i = 0  #记录符合要求的密码个数
while i < int(count):
    passwd = set(random.sample(src,8)) #从字母和数字中随机抽取8位生成密码
    if passwd.intersection(string.ascii_uppercase) and passwd.intersection(string.ascii_lowercase) and passwd.intersection(string.digits): #判断密码中是否包含大小写字母和数字
       passwds.append(''.join(passwd))  #将集合转化为字符串
       i += 1      #每生成1个符合要求的密码，i加1
print(passwds)

#编程题4
def Dup(nums):
    if len(set(nums))==len(nums):
        return False
    else:
        return True
print(Dup([1,2,3,1]))

#编程题5
def Dup2(nums):
        st=set(nums)
        if len(nums)!=len(st):
            return True
        else:
            return False
print(Dup2([1,2,3,1]))
